FINORA — Android APK

Проект содержит готовую веб-версию Finora Pro внутри Android WebView.

Сборка:
1. Установите Android Studio.
2. Откройте папку FinoraAndroid.
3. Дождитесь синхронизации Gradle.
4. Build -> Build APK(s).
5. APK будет в app/build/outputs/apk/debug/app-debug.apk

Для телефона:
- передайте APK на Android;
- откройте его;
- разрешите установку из этого источника, если Android попросит.

Данные Finora хранятся локально на устройстве через localStorage.
